# FFmpeg Source Owner

`runtime/third_party/ffmpeg/` owns the exact FFmpeg source and build profile consumed by Runtime. `src/` is the only implementation truth; CMake never downloads FFmpeg, resolves a host installation or consumes a prebuilt archive.

The fixed profile builds static PIC copies of `libavformat`, `libavcodec`, `libavutil`, `libswresample` and `libswscale`. Its allowlist is:

- decoders: H.264, HEVC, MJPEG, AAC, AMR-NB and Opus;
- encoders: MJPEG and AAC;
- parsers: H.264 and HEVC;
- muxers and protocols: MOV/MP4 output and local `file` only.

GPL, nonfree, version3, x264/x265/OpenH264, OpenCORE bindings, H.264/H.265 software encoders, hardware accelerators, network protocols, demuxers and the unused avfilter/avdevice libraries are disabled. `cmake/FFmpegProfile.cmake` is the single feature profile.

## Build and cache

The target is `tirtc_third::ffmpeg`. It uses the common third-party platform fingerprint and builds only from `src/` into:

```text
.build/third-party/<platform>/<fingerprint>/ffmpeg/
├── build/
├── stage/
│   ├── include/
│   └── lib/
└── build-manifest.json
```

Deleting this cache forces an offline rebuild from the repository. An unchanged warm build reuses the ExternalProject stamps and staged libraries. The fingerprint covers source content, platform/toolchain inputs, the feature profile, wrapper and build-profile verifier.

The install step runs `tools/verify_build_profile.py`. It rejects a license/configuration mismatch, any codec outside the allowlist, forbidden component families or symbols, and any archive layout other than the five expected libraries. Native macOS/Linux builds additionally link and execute a probe against `avcodec_license()`, `avcodec_configuration()` and the runtime codec registry. Cross builds record the same generated configuration and symbol evidence without attempting to execute target code.

`METADATA.json`, `LICENSES/` and the generated platform `build-manifest.json` install under `share/licenses/tirtc/third_party/ffmpeg/`. Source/compliance archive and relink-kit delivery belong to the Runtime release owner; this directory does not publish or upload artifacts.

Source ownership verification:

```sh
python3 runtime/third_party/tools/verify_sources.py
```

Product behavior is verified through Runtime canonical builds and `runtime/validation/`; no parallel FFmpeg unit-test directory is maintained here.
