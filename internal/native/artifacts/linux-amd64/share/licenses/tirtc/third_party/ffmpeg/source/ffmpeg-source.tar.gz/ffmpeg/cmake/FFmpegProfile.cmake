set(TIRTC_FFMPEG_PROFILE_SCHEMA_VERSION 1)

set(TIRTC_FFMPEG_LIBRARIES
    avformat
    avcodec
    swresample
    swscale
    avutil
)

set(TIRTC_FFMPEG_DECODERS
    h264
    hevc
    mjpeg
    aac
    amrnb
    opus
)

set(TIRTC_FFMPEG_ENCODERS
    mjpeg
    aac
)

set(TIRTC_FFMPEG_PARSERS
    h264
    hevc
)

set(TIRTC_FFMPEG_COMMON_CONFIGURE_OPTIONS
    --prefix=/
    --disable-autodetect
    --disable-shared
    --enable-static
    --enable-pic
    --disable-programs
    --disable-doc
    --disable-everything
    --enable-small
    --enable-avcodec
    --enable-avutil
    --enable-swresample
    --enable-swscale
    --disable-avdevice
    --disable-avfilter
    --enable-avformat
    --disable-network
    --disable-protocols
    --disable-demuxers
    --disable-muxers
    --disable-filters
    --disable-bsfs
    --disable-indevs
    --disable-outdevs
    --disable-hwaccels
    --disable-bzlib
    --disable-iconv
    --disable-lzma
    --disable-sdl2
    --disable-xlib
    --disable-zlib
    --disable-appkit
    --disable-audiotoolbox
    --disable-avfoundation
    --disable-coreimage
    --disable-metal
    --disable-securetransport
    --disable-videotoolbox
    --disable-vulkan
    --disable-debug
)

list(APPEND TIRTC_FFMPEG_COMMON_CONFIGURE_OPTIONS
    --enable-muxer=mp4
    --enable-protocol=file
)

foreach(_tirtc_ffmpeg_decoder IN LISTS TIRTC_FFMPEG_DECODERS)
    list(APPEND TIRTC_FFMPEG_COMMON_CONFIGURE_OPTIONS
        "--enable-decoder=${_tirtc_ffmpeg_decoder}"
    )
endforeach()

foreach(_tirtc_ffmpeg_encoder IN LISTS TIRTC_FFMPEG_ENCODERS)
    list(APPEND TIRTC_FFMPEG_COMMON_CONFIGURE_OPTIONS
        "--enable-encoder=${_tirtc_ffmpeg_encoder}"
    )
endforeach()

foreach(_tirtc_ffmpeg_parser IN LISTS TIRTC_FFMPEG_PARSERS)
    list(APPEND TIRTC_FFMPEG_COMMON_CONFIGURE_OPTIONS
        "--enable-parser=${_tirtc_ffmpeg_parser}"
    )
endforeach()

unset(_tirtc_ffmpeg_decoder)
unset(_tirtc_ffmpeg_encoder)
unset(_tirtc_ffmpeg_parser)
